const BASE_URL = "http://sq5t2teste-env.eba-vwdhhprt.us-east-1.elasticbeanstalk.com/";
export default BASE_URL;